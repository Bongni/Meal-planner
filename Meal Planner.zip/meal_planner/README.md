# meal_planner
An android app that plans your meals for the next week
