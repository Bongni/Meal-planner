package com.example.mealplanner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Recipe(title: String, ingredients: LinkedHashMap<String, Pair<Int, String>>) : AppCompatActivity() {
    private lateinit var titleField: TextView
    private lateinit var ingredientsField: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe)

        titleField = findViewById(R.id.titleField)
        ingredientsField = findViewById(R.id.ingredientsField)

        titleField.text = title
        ingredientsField.text = "Some ingredients no"
    }
}